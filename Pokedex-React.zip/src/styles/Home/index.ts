import styled from "styled-components";

export const ContainerCardPokemon = styled.section`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
`;
