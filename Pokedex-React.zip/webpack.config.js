module.exports = {
  //...
  watch: true,
};
