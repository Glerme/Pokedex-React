import styled from "styled-components";

export const InputSearchContainer = styled.div`
  display: flex;
  border: 1px solid #c5c5c5;
  border-radius: 10px;

  justify-content: center;
  align-items: center;

  margin: 1rem auto;
  width: 50%;
  padding: 0.5rem;

  & input {
    width: 100%;
    padding: 0.5rem;
    outline: 0;
    border: 0;

    background-color: transparent;

    font-size: 1.2rem;

    &:-webkit-autofill {
      box-shadow: 0 0 0 30px white inset;
    }
  }

  & button {
    font-size: 0;
    background: transparent;
    border: 0;
    padding: 0 0.5rem;

    & > svg {
      fill: #a6a6a6;
      transition: fill 0.5s;

      &:hover {
        fill: red;
      }
    }
  }
`;
