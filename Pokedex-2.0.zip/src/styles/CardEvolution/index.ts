import styled from "styled-components";

export const ContainerCardEvolution = styled.div`
  & > header {
    display: flex;
    justify-content: center;
    margin-top: 3rem;

    @media (max-width: 800px) {
      justify-content: left;

      flex-direction: column;
    }

    & > div {
      margin: 1rem;
      & > img {
        width: 100%;
        justify-content: center;
        padding: 1rem;
      }
    }
  }

  & > footer {
    display: flex;
    justify-content: space-around;

    & > div {
      & > p {
        font-size: 1.5rem;
        text-transform: capitalize;

        margin-bottom: 0.2rem;
        color: var(--text-third);
      }

      & > span {
        font-size: 1.1rem;
        color: var(--text-secondary);
      }
    }

    @media (max-width: 715px) {
      justify-content: left;
      flex-direction: column;
    }
  }
`;
