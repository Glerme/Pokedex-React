import { Evolucao } from "../types/PokemonTypes";

const getPokemonNameAndId = (name: string, url: string) => {
  return {
    id: url.replace(/^.*\/(\d+)\/?$/g, "$1"),
    name: name,
  };
};

export const chainEvo = ({ chain }: Evolucao) => {
  const pokeAtual = getPokemonNameAndId(chain.species.name, chain.species.url);

  const especie1 = chain.evolves_to
    ? chain.evolves_to.map((evolucoes) => {
        return getPokemonNameAndId(
          evolucoes.species.name,
          evolucoes.species.url
        );
      })
    : [];

  const especie2 = chain.evolves_to[0]?.evolves_to
    ? chain.evolves_to[0].evolves_to.map((evolucoes) => {
        return getPokemonNameAndId(
          evolucoes.species.name,
          evolucoes.species.url
        );
      })
    : [];

  const parsedData = [pokeAtual, ...especie1, ...especie2];

  return parsedData;
};
