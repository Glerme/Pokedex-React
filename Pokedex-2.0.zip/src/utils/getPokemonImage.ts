export const getPokemonImage = (id: number[] | string[] | number | string) => {
  if (id < 100) {
    const newId = id.toString().padStart(3, "0");
    const url = new URL(process.env.IMAGE_API_URL + newId + ".png");
    return url.toString();
  } else {
    const url = new URL(process.env.IMAGE_API_URL + id + ".png");
    return url.toString();
  }
};
