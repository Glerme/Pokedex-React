import { NextPage } from "next";
import { useCallback, useEffect, useState } from "react";
import { api } from "../../services/api";

import * as Styled from "../../styles/Evolution";
import { EvolutionProps, EvolutionsData } from "../../types/PokemonEvolution";
import { Evolucao, PokemonSpecies } from "../../types/PokemonTypes";
import { chainEvo } from "../../utils/chainEvo";
import { getPokemonImage } from "../../utils/getPokemonImage";
import CardEvolutions from "../CardEvolutions";

const Evolutions: NextPage<EvolutionsData> = ({ pokemonData }) => {
  const [imgPokemon, setImgPokemon] = useState([]);
  const [evolution, setEvolution] = useState<EvolutionProps[]>([]);

  const [nameImgPokemon, setNameImgPokemon] = useState<any[]>([]);

  const buscar = useCallback(async () => {
    try {
      const { data: species } = await api.get<PokemonSpecies>(
        pokemonData.species.url
      );

      const { data: chain } = await api.get<Evolucao>(
        species.evolution_chain.url
      );

      const evolucoes = chainEvo(chain);

      // const idsImg = evolucoes.map((evo) => evo.id);

      const parsed = evolucoes.map((evo) => {
        return {
          ...evo,
          url: getPokemonImage(evo.id),
        };
      });

      console.log(parsed);

      // const url = idsImg.map((id) => {
      //   const url = getPokemonImage(id);
      //   return url;
      // });

      // setImgPokemon(url);
      // setEvolution(evolucoes);
    } catch (erro) {
      console.log(erro);
    }
  }, [nameImgPokemon]);

  useEffect(() => {
    buscar();
  }, []);

  return (
    <Styled.EvolutionContainer>
      <CardEvolutions nameImgPokemon={nameImgPokemon} />
    </Styled.EvolutionContainer>
  );
};

export default Evolutions;
