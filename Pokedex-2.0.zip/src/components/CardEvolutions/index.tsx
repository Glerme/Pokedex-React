import { NextPage } from "next";

import { EvolutionProps } from "../../types/PokemonEvolution";

import * as Styled from "../../styles/CardEvolution";

interface CardEvolutionsData {
  nameImgPokemon: any[];
}

const CardEvolutions: NextPage<CardEvolutionsData> = ({ nameImgPokemon }) => {
  return (
    <Styled.ContainerCardEvolution>
      {nameImgPokemon.map((pokemon) => (
        <div>
          <img src={pokemon.url} alt="" />

          <p>{pokemon.name}</p>
          <span>{pokemon.id}</span>
        </div>
      ))}

      {/* <header>
        {imgPokemon.map((imagem, index) => (
          <div>
            <img key={index} src={imagem} />
          </div>
        ))}
      </header>

      <footer>
        {evolution.map(({ id, name }) => {
          return (
            <div key={id}>
              <p>{name}</p>
              <span>#{id}</span>
            </div>
          );
        })}
      </footer> */}
    </Styled.ContainerCardEvolution>
  );
};

export default CardEvolutions;
